# Show Six - October 2020 - Indie

## Marine Girls - Times We Used to Spend

## Marine Girls - Such a Thing

## Cocteau Twins - Alas Dies Laughing

## Cocteau Twins - My Truth

## Dif Juz - CS

Dif Juz

Alan Curtis Duran Duran

## Dif Juz- Soarn

## Felt - Primitive Painters

## Felt - Fortune

## The Cure - A Forest

## Warpaint - Stars

## Hugo Largo - Turtle Song

## Kitchens of Distinction - Drive that Fast

## Orange Juice - Falling and Laughing

## Pale Saints - Shell

## A C Marias - One of our girls has gone missing

[https://jivetimerecords.com/2020/07/a-c-marias-one-of-our-girls-has-gone-missing-mute-1989/](https://jivetimerecords.com/2020/07/a-c-marias-one-of-our-girls-has-gone-missing-mute-1989/)

## A.R. Kane - Lollita

[https://crystalspires.livejournal.com/3173.html](https://crystalspires.livejournal.com/3173.html)

## A.R. Kane - Spermwhale trip over

MARRS

## 

## The Sugarcubes - Birthday